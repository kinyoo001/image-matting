import{f as e}from"./index-iE9K2__4.js";async function m(a,s){return await e(`compress_image__${a}`,s)}export{m as c};
