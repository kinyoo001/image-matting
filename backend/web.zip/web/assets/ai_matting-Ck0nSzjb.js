import{f as i}from"./index-iE9K2__4.js";async function r(a,t){return await i(`ai_matting__${a}`,t)}export{r as a};
