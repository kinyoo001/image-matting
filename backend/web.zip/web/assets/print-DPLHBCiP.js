import{f as a}from"./index-iE9K2__4.js";async function i(r,t){return await a(`print__${r}`,t)}export{i as p};
