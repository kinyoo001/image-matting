import{f as r}from"./index-iE9K2__4.js";async function n(a,e){return await r(`convert_image__${a}`,e)}export{n as c};
